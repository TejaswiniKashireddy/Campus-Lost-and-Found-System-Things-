# 🎒 Campus Lost & Found System

A Flask web app for college students to report and search for lost & found items.

---

## ▶️ How to Run (3 steps only)

### Step 1 — Install Python
Download Python 3.8+ from https://www.python.org and install it.
✅ Make sure to check **"Add Python to PATH"** during installation.

### Step 2 — Install Flask
Open **Command Prompt** (Windows) or **Terminal** (Mac/Linux) and run:
```
pip install flask werkzeug
```

### Step 3 — Run the App
Navigate to the project folder and run:
```
python run.py
```

Then open your browser and go to:
**http://127.0.0.1:5000**

That's it! 🎉

---

## 🔐 Login Credentials

| Role    | Username | Password  |
|---------|----------|-----------|
| Admin   | admin    | admin123  |

Register new student accounts from the Register page.

---

## 📁 Project Structure

```
campus-lost-found-system/
├── run.py              ← START HERE — runs the app
├── app.py              ← Flask backend (all routes)
├── database.db         ← SQLite database (auto-created)
├── requirements.txt    ← Dependencies list
├── templates/          ← HTML pages
│   ├── base.html
│   ├── login.html
│   ├── register.html
│   ├── home.html
│   ├── post_item.html
│   ├── item_details.html
│   ├── my_posts.html
│   ├── profile.html
│   └── admin.html
├── static/
│   ├── css/style.css   ← All styling
│   ├── js/script.js    ← UI interactions
│   └── images/uploads/ ← Uploaded photos stored here
└── models/
    ├── user_model.py
    └── item_model.py
```

---

## ✨ Features

- **Register / Login / Logout** with secure password hashing
- **Home Dashboard** — latest lost & found item cards with search
- **Post Lost Item** — name, description, location, date, contact, photo
- **Post Found Item** — same form, tagged as "found"
- **Search** — filter by item name and/or location
- **My Posts** — view, mark recovered, delete your own posts
- **Item Details** — full info + contact the poster
- **Profile Page** — account info and activity stats
- **Admin Panel** — view all users, delete any post

---

## 🗄️ Database Tables

**users** — id, username, email, password, is_admin, created_at

**items** — id, title, description, type (lost/found), location, date, contact, image, user_id, status (open/recovered), created_at

---

## ⭐ Optional Upgrades

- Google Maps location picker
- Email notification on match
- Chat between finder and owner
- Pagination for large item lists
- Dark mode toggle
