"""
run.py — Start the Campus Lost & Found System
Just run:  python run.py
"""
import subprocess, sys, os

# Auto-install dependencies if missing
try:
    import flask
    from werkzeug.security import generate_password_hash
except ImportError:
    print("Installing required packages...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "flask", "werkzeug"])
    print("Done! Starting app...\n")

# Now launch the app
os.chdir(os.path.dirname(os.path.abspath(__file__)))
from app import app, init_db

if __name__ == "__main__":
    init_db()
    print("\n✅  Campus Lost & Found is running!")
    print("🌐  Open your browser: http://127.0.0.1:5000")
    print("🔐  Admin login  →  username: admin  |  password: admin123")
    print("    Press Ctrl+C to stop.\n")
    app.run(debug=True, use_reloader=False)
