import os, sqlite3, uuid
from flask import (Flask, render_template, request, redirect,
                   url_for, session, flash, g)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime
from functools import wraps

app = Flask(__name__)
app.secret_key = "campus_lnf_2024_secret"

DATABASE      = os.path.join(os.path.dirname(__file__), "database.db")
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), "static", "images", "uploads")
ALLOWED_EXT   = {"png", "jpg", "jpeg", "gif", "webp"}

os.makedirs(UPLOAD_FOLDER, exist_ok=True)


# ── DB helpers ────────────────────────────────────────────────────────────────

def get_db():
    db = getattr(g, "_db", None)
    if db is None:
        db = g._db = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_db(e):
    db = getattr(g, "_db", None)
    if db: db.close()

def init_db():
    with app.app_context():
        db = get_db()
        db.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                username   TEXT UNIQUE NOT NULL,
                email      TEXT UNIQUE NOT NULL,
                password   TEXT NOT NULL,
                is_admin   INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS items (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                title       TEXT NOT NULL,
                description TEXT,
                type        TEXT NOT NULL CHECK(type IN ('lost','found')),
                location    TEXT NOT NULL,
                date        TEXT NOT NULL,
                contact     TEXT NOT NULL,
                image       TEXT,
                user_id     INTEGER NOT NULL,
                status      TEXT DEFAULT 'open',
                created_at  TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
        """)
        if not db.execute("SELECT id FROM users WHERE username='admin'").fetchone():
            db.execute(
                "INSERT INTO users (username,email,password,is_admin) VALUES (?,?,?,1)",
                ("admin", "admin@campus.edu", generate_password_hash("admin123"))
            )
        db.commit()


# ── Auth decorators ───────────────────────────────────────────────────────────

def login_required(f):
    @wraps(f)
    def wrapped(*a, **kw):
        if "user_id" not in session:
            flash("Please log in first.", "warning")
            return redirect(url_for("login"))
        return f(*a, **kw)
    return wrapped

def admin_required(f):
    @wraps(f)
    def wrapped(*a, **kw):
        if session.get("is_admin") != 1:
            flash("Admin access only.", "danger")
            return redirect(url_for("home"))
        return f(*a, **kw)
    return wrapped


# ── Helpers ───────────────────────────────────────────────────────────────────

def allowed(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXT

def save_image(file):
    if file and file.filename and allowed(file.filename):
        ext  = file.filename.rsplit(".", 1)[1].lower()
        name = f"{uuid.uuid4().hex}.{ext}"
        file.save(os.path.join(UPLOAD_FOLDER, name))
        return name
    return None


# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return redirect(url_for("home"))


@app.route("/home")
def home():
    db  = get_db()
    q   = request.args.get("q",        "").strip()
    loc = request.args.get("location", "").strip()

    conds, params = [], []
    if q:   conds.append("items.title LIKE ?");    params.append(f"%{q}%")
    if loc: conds.append("items.location LIKE ?"); params.append(f"%{loc}%")
    where = ("WHERE " + " AND ".join(conds)) if conds else ""

    base = "SELECT items.*, users.username FROM items JOIN users ON items.user_id=users.id "

    lost_items  = db.execute(base + where + (" AND " if where else "WHERE ") +
                             "items.type='lost'  ORDER BY items.created_at DESC LIMIT 12", params).fetchall()
    found_items = db.execute(base + where + (" AND " if where else "WHERE ") +
                             "items.type='found' ORDER BY items.created_at DESC LIMIT 12", params).fetchall()

    # fix: if there is a WHERE clause already, use AND; otherwise WHERE
    if where:
        lost_items  = db.execute(base + where + " AND items.type='lost'  ORDER BY items.created_at DESC LIMIT 12", params).fetchall()
        found_items = db.execute(base + where + " AND items.type='found' ORDER BY items.created_at DESC LIMIT 12", params).fetchall()
    else:
        lost_items  = db.execute(base + "WHERE items.type='lost'  ORDER BY items.created_at DESC LIMIT 12", []).fetchall()
        found_items = db.execute(base + "WHERE items.type='found' ORDER BY items.created_at DESC LIMIT 12", []).fetchall()

        if q or loc:
            lost_items  = db.execute(base + where + " AND items.type='lost'  ORDER BY items.created_at DESC", params).fetchall()  if where else lost_items
            found_items = db.execute(base + where + " AND items.type='found' ORDER BY items.created_at DESC", params).fetchall() if where else found_items

    # simpler rewrite
    def fetch(item_type):
        c2, p2 = list(conds), list(params)
        c2.append("items.type=?"); p2.append(item_type)
        w2 = "WHERE " + " AND ".join(c2)
        return db.execute(base + w2 + " ORDER BY items.created_at DESC LIMIT 12", p2).fetchall()

    lost_items  = fetch("lost")
    found_items = fetch("found")

    stats = {
        "total_lost":  db.execute("SELECT COUNT(*) FROM items WHERE type='lost'").fetchone()[0],
        "total_found": db.execute("SELECT COUNT(*) FROM items WHERE type='found'").fetchone()[0],
        "total_users": db.execute("SELECT COUNT(*) FROM users WHERE is_admin=0").fetchone()[0],
    }
    return render_template("home.html", lost_items=lost_items, found_items=found_items,
                           stats=stats, q=q, loc=loc)


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        u  = request.form["username"].strip()
        e  = request.form["email"].strip()
        p  = request.form["password"]
        p2 = request.form["confirm_password"]
        if p != p2:
            flash("Passwords do not match.", "danger")
            return redirect(url_for("register"))
        db = get_db()
        if db.execute("SELECT id FROM users WHERE username=?", (u,)).fetchone():
            flash("Username already taken.", "danger"); return redirect(url_for("register"))
        if db.execute("SELECT id FROM users WHERE email=?", (e,)).fetchone():
            flash("Email already registered.", "danger"); return redirect(url_for("register"))
        db.execute("INSERT INTO users (username,email,password) VALUES (?,?,?)",
                   (u, e, generate_password_hash(p)))
        db.commit()
        flash("Account created! Please log in.", "success")
        return redirect(url_for("login"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        ident = request.form["identifier"].strip()
        pwd   = request.form["password"]
        db    = get_db()
        user  = db.execute("SELECT * FROM users WHERE username=? OR email=?", (ident, ident)).fetchone()
        if user and check_password_hash(user["password"], pwd):
            session["user_id"]  = user["id"]
            session["username"] = user["username"]
            session["is_admin"] = user["is_admin"]
            flash(f"Welcome back, {user['username']}! 👋", "success")
            return redirect(url_for("home"))
        flash("Invalid username or password.", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("login"))


@app.route("/post/<item_type>", methods=["GET", "POST"])
@login_required
def post_item(item_type):
    if item_type not in ("lost", "found"):
        return redirect(url_for("home"))
    if request.method == "POST":
        img = save_image(request.files.get("image"))
        db  = get_db()
        db.execute(
            "INSERT INTO items (title,description,type,location,date,contact,image,user_id) VALUES (?,?,?,?,?,?,?,?)",
            (request.form["title"].strip(),
             request.form["description"].strip(),
             item_type,
             request.form["location"].strip(),
             request.form["date"],
             request.form["contact"].strip(),
             img,
             session["user_id"])
        )
        db.commit()
        flash(f"Your {item_type} item has been posted! ✅", "success")
        return redirect(url_for("home"))
    return render_template("post_item.html", item_type=item_type,
                           today=datetime.today().strftime("%Y-%m-%d"))


@app.route("/item/<int:item_id>")
def item_details(item_id):
    db   = get_db()
    item = db.execute(
        "SELECT items.*, users.username, users.email FROM items "
        "JOIN users ON items.user_id=users.id WHERE items.id=?", (item_id,)
    ).fetchone()
    if not item:
        flash("Item not found.", "danger"); return redirect(url_for("home"))
    return render_template("item_details.html", item=item)


@app.route("/my-posts")
@login_required
def my_posts():
    items = get_db().execute(
        "SELECT * FROM items WHERE user_id=? ORDER BY created_at DESC",
        (session["user_id"],)
    ).fetchall()
    return render_template("my_posts.html", items=items)


@app.route("/delete/<int:item_id>", methods=["POST"])
@login_required
def delete_item(item_id):
    db   = get_db()
    item = db.execute("SELECT * FROM items WHERE id=?", (item_id,)).fetchone()
    if not item:
        flash("Item not found.", "danger"); return redirect(url_for("my_posts"))
    if item["user_id"] != session["user_id"] and session.get("is_admin") != 1:
        flash("Permission denied.", "danger"); return redirect(url_for("my_posts"))
    if item["image"]:
        path = os.path.join(UPLOAD_FOLDER, item["image"])
        if os.path.exists(path): os.remove(path)
    db.execute("DELETE FROM items WHERE id=?", (item_id,))
    db.commit()
    flash("Item deleted.", "success")
    return redirect(request.referrer or url_for("my_posts"))


@app.route("/toggle-status/<int:item_id>", methods=["POST"])
@login_required
def toggle_status(item_id):
    db   = get_db()
    item = db.execute("SELECT * FROM items WHERE id=?", (item_id,)).fetchone()
    if item and item["user_id"] == session["user_id"]:
        new = "recovered" if item["status"] == "open" else "open"
        db.execute("UPDATE items SET status=? WHERE id=?", (new, item_id))
        db.commit()
        flash(f"Marked as {new}.", "success")
    return redirect(request.referrer or url_for("my_posts"))


@app.route("/profile")
@login_required
def profile():
    db         = get_db()
    user       = db.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
    post_count = db.execute("SELECT COUNT(*) FROM items WHERE user_id=?",   (session["user_id"],)).fetchone()[0]
    lost_count = db.execute("SELECT COUNT(*) FROM items WHERE user_id=? AND type='lost'",  (session["user_id"],)).fetchone()[0]
    found_count= db.execute("SELECT COUNT(*) FROM items WHERE user_id=? AND type='found'", (session["user_id"],)).fetchone()[0]
    return render_template("profile.html", user=user, post_count=post_count,
                           lost_count=lost_count, found_count=found_count)


@app.route("/admin")
@login_required
@admin_required
def admin():
    db    = get_db()
    users = db.execute(
        "SELECT *, (SELECT COUNT(*) FROM items WHERE user_id=users.id) AS post_count "
        "FROM users ORDER BY created_at DESC"
    ).fetchall()
    items = db.execute(
        "SELECT items.*, users.username FROM items "
        "JOIN users ON items.user_id=users.id ORDER BY items.created_at DESC"
    ).fetchall()
    return render_template("admin.html", users=users, items=items)
