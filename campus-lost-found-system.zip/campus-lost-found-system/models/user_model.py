import sqlite3

DB = 'database.db'

def get_user_by_id(user_id):
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row
    row = con.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone(); con.close(); return row

def get_all_users():
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row
    rows = con.execute("SELECT * FROM users ORDER BY created_at DESC").fetchall(); con.close(); return rows
