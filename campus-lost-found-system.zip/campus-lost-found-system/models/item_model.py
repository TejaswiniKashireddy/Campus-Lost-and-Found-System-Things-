import sqlite3

DB = 'database.db'

def get_item_by_id(item_id):
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row
    row = con.execute("SELECT items.*,users.username FROM items JOIN users ON items.user_id=users.id WHERE items.id=?", (item_id,)).fetchone(); con.close(); return row

def get_items_by_type(item_type, limit=12):
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row
    rows = con.execute("SELECT items.*,users.username FROM items JOIN users ON items.user_id=users.id WHERE items.type=? ORDER BY items.created_at DESC LIMIT ?", (item_type, limit)).fetchall(); con.close(); return rows

def search_items(query='', location=''):
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row
    conds, params = ["1=1"], []
    if query:    conds.append("items.title LIKE ?");    params.append(f'%{query}%')
    if location: conds.append("items.location LIKE ?"); params.append(f'%{location}%')
    rows = con.execute(f"SELECT items.*,users.username FROM items JOIN users ON items.user_id=users.id WHERE {' AND '.join(conds)} ORDER BY items.created_at DESC", params).fetchall(); con.close(); return rows
